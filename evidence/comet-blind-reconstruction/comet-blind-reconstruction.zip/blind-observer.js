(function () {
  const seed = Number(new URL(location.href).searchParams.get("seed"));
  let randomState = seed;
  Math.random = () => {
    randomState = (Math.imul(randomState, 1664525) + 1013904223) >>> 0;
    return randomState / 2 ** 32;
  };
  let nextFrame;
  window.requestAnimationFrame = (callback) => { nextFrame = callback; return 1; };
  const errors = [];
  window.addEventListener("error", (event) => errors.push(event.message));

  let rectangles = [];
  let strings = [];
  const context = CanvasRenderingContext2D.prototype;
  const fillRect = context.fillRect;
  const fillText = context.fillText;
  context.fillRect = function (...args) {
    rectangles.push([...args, this.fillStyle]);
    return fillRect.apply(this, args);
  };
  context.fillText = function (...args) {
    strings.push([...args, this.fillStyle]);
    return fillText.apply(this, args);
  };

  function sample() {
    const score = strings.map(([text]) => /^SCORE\s+(\d+)/i.exec(text)).find(Boolean);
    const lifeIcons = rectangles.filter(([x, y, w, h]) => y === 5 && x >= 120 && w === 5 && h === 5);
    const ship = rectangles.find(([, y, w, h]) => y === 219 && w === 6 && h === 5);
    const hazards = rectangles.filter(([, , w, h]) => w === 2 && h === 4).map((rect) => rect.slice(0, 2));
    return {
      score: score ? Number(score[1]) : null,
      lives: lifeIcons.length,
      over: strings.some(([text]) => /GAME\s+OVER/i.test(text)),
      shipX: ship ? ship[0] + 3 : null,
      hazards,
      geometry: [rectangles.map((rect) => rect.slice(0, 4)), strings.map((line) => line.slice(0, 3))]
    };
  }

  window.addEventListener("load", () => {
    setTimeout(() => {
      const trace = [];
      for (let i = 0; i < 800 && nextFrame; i++) {
        const direction = Math.floor(i / 73) % 4;
        for (const [key, pressed] of [["ArrowLeft", direction === 1], ["ArrowRight", direction === 3]]) {
          window.dispatchEvent(new KeyboardEvent(pressed ? "keydown" : "keyup", { key, bubbles: true, cancelable: true }));
        }
        if (seed === 2028 && i >= 640 && i <= 641) {
          window.dispatchEvent(new KeyboardEvent(i === 640 ? "keydown" : "keyup", { key: " ", bubbles: true, cancelable: true }));
        }
        const callback = nextFrame;
        nextFrame = null;
        rectangles = [];
        strings = [];
        try {
          callback((i + 1) * (1000 / 60));
          const row = sample();
          // Retain a compact geometry comparison independent of cosmetic colors and pixel post-processing.
          let hash = 2166136261;
          for (const ch of JSON.stringify(row.geometry)) hash = Math.imul(hash ^ ch.charCodeAt(0), 16777619);
          row.geometry = (hash >>> 0).toString(16);
          trace.push(row);
        } catch (error) {
          errors.push(error.message);
          break;
        }
      }
      const canvas = document.querySelector("canvas");
      const data = document.createElement("script");
      data.type = "application/json";
      data.id = "blind-replay-data";
      data.textContent = JSON.stringify({
        errors,
        browser: navigator.userAgent,
        canvas: canvas ? [canvas.width, canvas.height] : null,
        png: canvas?.toDataURL("image/png").split(",")[1],
        trace
      });
      document.body.append(data);
    }, 0);
  });
})();
