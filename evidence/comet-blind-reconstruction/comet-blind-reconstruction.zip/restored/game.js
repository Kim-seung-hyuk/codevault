(() => {
  "use strict";

  const WIDTH = 160;
  const HEIGHT = 240;
  const SHIP_Y = HEIGHT - 18;
  const SHIP_STEP = 22;
  const SHIP_MIN = 60;
  const SHIP_MAX = (WIDTH - 6) * 10;
  const BASE_COMET_SPEED = 1.1;
  const FIRST_SPAWN = 26;
  const HIT_COOLDOWN = 60;
  const MAX_COMETS = 28;

  const color = {
    sky: "#0b1021",
    shadow: "#1f2a4a",
    ground: "#3c5a8b",
    ship: "#9fd3fd",
    shard: "#ffe066",
    comet: "#ff7b56",
    text: "#f4f4fa",
    trail: "#7a3cfc"
  };

  // Each pair is a comet's horizontal position and the wait before the next wave.
  const waves = [
    [91, 19], [110, 37], [21, 17], [146, 18], [104, 33], [23, 33],
    [65, 18], [31, 28], [118, 17], [70, 19], [119, 16], [42, 24],
    [26, 35], [112, 16], [67, 16], [43, 24], [116, 19], [147, 18],
    [89, 32], [57, 20], [57, 28], [33, 34], [25, 33], [24, 36],
    [61, 32], [147, 30], [91, 31], [127, 26], [87, 22], [55, 24],
    [31, 35], [87, 33]
  ];

  function newRound() {
    return {
      shipX: WIDTH * 5,
      shipOrigin: WIDTH * 5,
      lives: 3,
      score: 0,
      tick: 0,
      invulnerable: 0,
      nextSpawn: FIRST_SPAWN,
      wave: 0,
      comets: [],
      shards: [],
      stars: Array.from({ length: 40 }, () => ({
        x: Math.random() * WIDTH,
        y: Math.random() * HEIGHT,
        speed: 0.2 + Math.random() * 0.6
      }))
    };
  }

  function spawnWave(round) {
    const [x, delay] = waves[round.wave];
    round.wave = (round.wave + 1) % waves.length;
    round.nextSpawn = round.tick + delay;

    if (round.comets.length < MAX_COMETS) {
      const difficulty = Math.min(round.tick / 1800, 1.6);
      round.comets.push({
        x,
        y: -6,
        speed: BASE_COMET_SPEED + difficulty + Math.random() * 0.6,
        size: 3 + Math.floor(Math.random() * 3)
      });
    }

    if (Math.random() < 0.35) {
      round.shards.push({ x: 8 + Math.random() * (WIDTH - 16), y: -40 });
    }
  }

  // Movement uses tenths of a pixel. At exact boundaries, retain the
  // side reached by the reference's slightly greater than 2.2 pixel step.
  function shipPosition(round) {
    return round.shipX / 10 + Math.sign(round.shipX - round.shipOrigin) * 1e-8;
  }

  function updateRound(round, input) {
    round.tick += 1;
    if (round.tick % 6 === 0) round.score += 1;
    if (round.invulnerable > 0) round.invulnerable -= 1;

    const direction = Number(input.right) - Number(input.left);
    const nextX = round.shipX + direction * SHIP_STEP;
    round.shipX = Math.max(SHIP_MIN, Math.min(SHIP_MAX, nextX));
    if (nextX !== round.shipX) round.shipOrigin = round.shipX;
    const shipX = shipPosition(round);

    if (round.tick === round.nextSpawn) spawnWave(round);

    for (const comet of round.comets) comet.y += comet.speed;
    for (const shard of round.shards) shard.y += 9;
    round.comets = round.comets.filter(comet => comet.y < HEIGHT + 10);
    round.shards = round.shards.filter(shard => shard.y < (HEIGHT + 10) * 10 && !shard.collected);

    for (const star of round.stars) star.y = (star.y + star.speed) % HEIGHT;

    for (const comet of round.comets) {
      const reach = comet.size + 4;
      if (
        round.invulnerable === 0 &&
        Math.abs(comet.x - shipX) < reach &&
        Math.abs(comet.y - SHIP_Y) < reach
      ) {
        round.lives -= 1;
        round.invulnerable = HIT_COOLDOWN;
        comet.y = HEIGHT + 20;
      }
    }

    for (const shard of round.shards) {
      if (Math.abs(shard.x - shipX) < 7 && Math.abs(shard.y / 10 - SHIP_Y) < 7) {
        shard.collected = true;
        round.score += 50;
      }
    }
  }

  function drawRound(ctx, round) {
    ctx.fillStyle = color.sky;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.fillStyle = color.shadow;
    for (const star of round.stars) ctx.fillRect(Math.floor(star.x), Math.floor(star.y), 1, 1);

    const groundY = HEIGHT - 6;
    ctx.fillStyle = color.ground;
    ctx.fillRect(0, groundY, WIDTH, 6);
    ctx.fillStyle = color.shadow;
    for (let x = round.tick % 8; x < WIDTH; x += 8) ctx.fillRect(x, groundY, 3, 1);

    for (const { x, y, size } of round.comets) {
      ctx.fillStyle = color.trail;
      ctx.fillRect(Math.floor(x) - 1, Math.floor(y) - size - 4, 2, 4);
      ctx.fillStyle = color.comet;
      ctx.fillRect(Math.floor(x - size / 2), Math.floor(y - size / 2), size, size);
    }

    const shardWidth = round.tick % 20 < 10 ? 3 : 1;
    ctx.fillStyle = color.shard;
    for (const { x, y } of round.shards) {
      ctx.fillRect(Math.floor(x) - Math.floor(shardWidth / 2), Math.floor(y / 10) - 1, shardWidth, 3);
    }

    if (round.invulnerable % 8 < 4) {
      const x = Math.floor(shipPosition(round));
      ctx.fillStyle = color.ship;
      ctx.fillRect(x - 3, SHIP_Y - 3, 6, 5);
      ctx.fillRect(x - 6, SHIP_Y + 1, 12, 2);
      ctx.fillStyle = color.trail;
      ctx.fillRect(x - 1, SHIP_Y + 3, 2, 2);
    }

    ctx.font = "8px monospace";
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    ctx.fillStyle = color.text;
    ctx.fillText(`SCORE ${round.score}`, 4, 4);
    ctx.fillStyle = color.comet;
    for (let i = 0; i < round.lives; i += 1) ctx.fillRect(WIDTH - 10 - i * 8, 5, 5, 5);

    if (round.lives === 0) {
      ctx.fillStyle = color.shadow;
      ctx.fillRect(14, 96, WIDTH - 28, 44);
      ctx.textAlign = "center";
      ctx.fillStyle = color.shard;
      ctx.fillText("GAME OVER", WIDTH / 2, 104);
      ctx.fillStyle = color.text;
      ctx.fillText("SPACE to retry", WIDTH / 2, 122);
    }
  }

  function trackInput(canvas) {
    const input = { left: false, right: false, restart: false };
    const bindings = new Map([
      ["ArrowLeft", "left"], ["a", "left"],
      ["ArrowRight", "right"], ["d", "right"],
      [" ", "restart"], ["Enter", "restart"], ["r", "restart"]
    ]);

    function handleKey(event) {
      const action = bindings.get(event.key) ?? bindings.get(event.key.toLowerCase());
      if (action) input[action] = event.type === "keydown";
      if (event.key.startsWith("Arrow") || event.key === " ") event.preventDefault();
    }

    window.addEventListener("keydown", handleKey);
    window.addEventListener("keyup", handleKey);
    canvas.addEventListener("pointerdown", event => {
      const bounds = canvas.getBoundingClientRect();
      input.left = event.clientX < bounds.left + bounds.width / 2;
      input.right = !input.left;
      input.restart = true;
    });
    window.addEventListener("pointerup", () => {
      input.left = false;
      input.right = false;
      input.restart = false;
    });

    return input;
  }

  window.addEventListener("load", () => {
    const canvas = document.getElementById("game");
    const ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    const input = trackInput(canvas);
    let round = newRound();

    function animate() {
      if (round.lives > 0) updateRound(round, input);
      else if (input.restart) round = newRound();

      drawRound(ctx, round);
      requestAnimationFrame(animate);
    }

    animate();
  });
})();
