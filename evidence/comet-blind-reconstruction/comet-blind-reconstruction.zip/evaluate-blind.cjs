const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { createRequire } = require("node:module");
const { pathToFileURL } = require("node:url");
const { createHash } = require("node:crypto");

const [project, issuedZip, restored, evidence, selectedBrowser] = process.argv.slice(2);
const req = createRequire(path.join(path.resolve(project), "lambda", "package.json"));
const { readPackage } = req("./lib/pkg");
const wm = req("./lib/watermark");
const outputMark = req("./lib/outputmark");
const dir = fs.mkdtempSync(path.join(__dirname, "browser-run-"));
const browser = selectedBrowser || "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const seeds = [2026, 2027, 2028];
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
const secret = "comet-watermark-replay-fixture-v1";
const source = fs.readFileSync(path.join(project, "games", "comet-shower", "game.js"), "utf8");
const reference = wm.semanticReference(source);
const zip = fs.readFileSync(issuedZip);
const input = { issued: readPackage(zip) };
if (restored !== "-") {
  input.restored = Object.fromEntries(["index.html", "game.js"].map(
    (name) => [name, fs.readFileSync(path.join(restored, name))]
  ));
}

function runBrowser(directory, seed) {
  const page = pathToFileURL(path.join(directory, "index.html"));
  page.searchParams.set("seed", seed);
  const result = spawnSync(browser, [
    "--headless", "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-background-networking",
    `--user-data-dir=${path.join(dir, "profile")}`, "--allow-file-access-from-files",
    "--dump-dom", "--virtual-time-budget=3000", page.href
  ], { encoding: "utf8", maxBuffer: 8 * 1024 * 1024, timeout: 40000, windowsHide: true });
  if (result.status !== 0) throw new Error(result.error?.message || result.stderr);
  const raw = result.stdout.match(/<script [^>]*id="blind-replay-data"[^>]*>(.*?)<\/script>/s)?.[1];
  if (!raw) throw new Error(`No replay results: ${result.stdout.slice(-1000)}`);
  const { png, ...data } = JSON.parse(raw);
  const screenshot = Buffer.from(png || "", "base64");
  return {
    ...data,
    screenFingerprint: png ? outputMark.extractImage(screenshot, { secret }).marks : [],
    screenSha256: png ? sha256(screenshot) : null
  };
}

function inspect(bytes, label) {
  const directory = path.join(dir, label);
  fs.mkdirSync(directory);
  const js = Buffer.from(bytes["game.js"]);
  const html = Buffer.from(bytes["index.html"]).toString("utf8");
  const adjusted = html.replace(/<head\b[^>]*>/i, '$&<script src="observer.js"></script>');
  assert.notEqual(adjusted, html, "Expected a <head> for replay instrumentation");
  fs.writeFileSync(path.join(directory, "index.html"), adjusted);
  fs.writeFileSync(path.join(directory, "game.js"), js);
  fs.copyFileSync(path.join(__dirname, "blind-observer.js"), path.join(directory, "observer.js"));
  const fingerprint = wm.extract(js.toString("utf8"), { secret, reference });
  return {
    jsSha256: sha256(js),
    htmlSha256: sha256(bytes["index.html"]),
    fingerprint: {
      decision: fingerprint.decision,
      markId: fingerprint.markId,
      confidence: fingerprint.confidence,
      agreeingLayers: fingerprint.agreeingLayers,
      L8: fingerprint.layers.L8
    },
    replays: Object.fromEntries(seeds.map((seed) => [seed, runBrowser(directory, seed)]))
  };
}

const issued = inspect(input.issued, "issued");
const restoredResult = input.restored ? inspect(input.restored, "restored") : null;
const comparison = restoredResult && Object.fromEntries(seeds.map((seed) => {
  const baseline = issued.replays[seed];
  const rebuilt = restoredResult.replays[seed];
  const keys = ["score", "lives", "over", "shipX", "hazards", "geometry"];
  const results = Object.fromEntries(keys.map((key) => {
    const mismatchFrames = baseline.trace.flatMap((frame, i) => (
      JSON.stringify(frame[key]) === JSON.stringify(rebuilt.trace[i]?.[key]) ? [] : [i + 1]
    ));
    return [key, { equalFrames: baseline.trace.length - mismatchFrames.length, firstMismatch: mismatchFrames[0] ?? null }];
  }));
  return [seed, {
    issuedFrames: baseline.trace.length,
    restoredFrames: rebuilt.trace.length,
    results,
    issuedLastFrame: baseline.trace.at(-1),
    restoredLastFrame: rebuilt.trace.at(-1)
  }];
}));
const report = { receivedZipSha256: sha256(zip), seeds, issued, restored: restoredResult, comparison };
if (evidence) fs.writeFileSync(evidence, JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify({
  issuedFingerprint: issued.fingerprint,
  restoredFingerprint: restoredResult?.fingerprint,
  issuedReplays: seeds.map((seed) => {
    const { errors, canvas, trace, screenFingerprint } = issued.replays[seed];
    return { seed, errors, canvas, frames: trace.length, screenFingerprint };
  }),
  restoredReplays: restoredResult && seeds.map((seed) => {
    const { errors, canvas, trace, screenFingerprint } = restoredResult.replays[seed];
    return { seed, errors, canvas, frames: trace.length, screenFingerprint };
  }),
  comparison
}, null, 2));
