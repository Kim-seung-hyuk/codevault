# Comet Shower 블라인드 복원 실험

`restored/index.html`을 브라우저로 열면 복원본을 플레이할 수 있다. `issued/comet-shower.zip`은 독립 작업 세션에 제공한 실제 입력 파일이다.

## 복원 조건

복원 세션에는 이 ZIP과 독립 구현 지시만 전달했다. 이전 대화, 고객사 원본 소스, 프로젝트 경로, 측정 기준, 지문의 존재와 삽입 위치는 전달하지 않았다. 복원 세션은 입력 ZIP의 소스를 읽을 수 있었다.

> Inspect the ZIP and write a clean, independently implemented, playable HTML/JavaScript reimplementation whose observable behavior is as close as possible to the game in the ZIP, including controls, timing, and game mechanics. Implement the code yourself rather than delivering the ZIP's executable source verbatim. Use your own judgment on what needs to be reproduced.

## 재현

Node.js, Chrome, 그리고 Lambda 의존성이 설치된 REA_Defence 프로젝트가 필요하다. 압축을 푼 폴더에서 실행한다. Chrome이 기본 경로에 없으면 첫 명령 끝에 실행 파일 경로를 추가한다. 발급에 쓴 키는 공개 실험용 고정 문자열이며 운영 키를 사용하지 않는다.

```powershell
node .\evaluate-blind.cjs '<REA_Defence 경로>' .\issued\comet-shower.zip .\restored .\evidence.json
node .\check-nested-waves.cjs '<REA_Defence 경로>' .\issued\comet-shower.zip .\restored .\evidence.json
```

평가기에서 Chrome으로 두 HTML을 열고 공통 시드에 맞춘 키 입력을 800개 프레임씩 보낸다. HUD에 그려진 점수·목숨·게임오버 표시, 우주선과 혜성 좌표, 도형·텍스트의 그리기 좌표를 비교한다. 마지막 프레임의 무손실 캔버스 PNG는 L7 검출에 사용한다. 기존 소스 검출기에는 실제 복원본 JS와 고객사 기준 데이터를 입력한다. 별도 데이터 대조 스크립트는 평가 결과에 배열 값의 일치 여부를 덧붙인다.
