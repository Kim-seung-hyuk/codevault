const fs = require("node:fs");
const path = require("node:path");
const { createRequire } = require("node:module");
const [project, zipPath, restoredDirectory, evidencePath] = process.argv.slice(2);
const req = createRequire(path.join(path.resolve(project), "lambda", "package.json"));
const { readPackage } = req("./lib/pkg");
const wm = req("./lib/watermark");
const semantic = req("./lib/semantic");
const secret = "comet-watermark-replay-fixture-v1";
const clean = fs.readFileSync(path.join(project, "games", "comet-shower", "game.js"), "utf8");
const issued = Buffer.from(readPackage(fs.readFileSync(zipPath))["game.js"]).toString("utf8");
const restored = fs.readFileSync(path.join(restoredDirectory, "game.js"), "utf8");
const reference = wm.semanticReference(clean);
const { rows: issuedRows } = wm.semanticReference(issued).tables.find(({ name }) => name === "WAVES");
const issuedValues = issuedRows.flat();

function scanArrays(code) {
  const found = [];
  function visit(node, depth) {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) {
      for (const item of node) visit(item, depth);
      return;
    }
    if (node.type === "VariableDeclarator" && node.id.type === "Identifier" && node.init?.type === "ArrayExpression") {
      const declaration = `const ${node.id.name} = ${code.slice(node.init.start, node.init.end)};`;
      const { tables } = wm.semanticReference(declaration);
      if (tables.length > 0) {
        const [{ rows }] = tables;
        const matching = rows.flat().filter((value, index) => value === issuedValues[index]).length;
        const result = semantic.detect(wm.parse(declaration), reference, secret);
        found.push({ name: node.id.name, depth, matchingIssuedValues: matching, issuedValues: issuedValues.length, rows: rows.length, result });
      }
    }
    const next = node.type === "BlockStatement" ? depth + 1 : depth;
    for (const child of Object.values(node)) visit(child, next);
  }
  visit(wm.parse(code), 0);
  return found;
}

const nestedTableDiagnostic = {
  method: "Inspect integer array declarations at any lexical depth and apply the existing L8 correlation to each candidate in isolation.",
  issued: scanArrays(issued),
  restored: scanArrays(restored),
  cleanControl: scanArrays(clean)
};
const evidence = JSON.parse(fs.readFileSync(evidencePath, "utf8"));
evidence.nestedTableDiagnostic = nestedTableDiagnostic;
fs.writeFileSync(evidencePath, JSON.stringify(evidence, null, 2) + "\n");
console.log(JSON.stringify(nestedTableDiagnostic, null, 2));
